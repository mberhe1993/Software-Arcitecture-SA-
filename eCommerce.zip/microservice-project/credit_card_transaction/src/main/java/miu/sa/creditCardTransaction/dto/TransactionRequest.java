package miu.sa.creditCardTransaction.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
public class TransactionRequest {
    private int paymentId;

}
