package miu.sa.payment.util;

public class ServicesEndpoint {
    public static String PAY_BANK_ACCOUNT_END_POINT = "pay";
    public static String PAY_CREDIT_CARD_END_POINT = "pay";
    public static String PAY_PAYPAL_CARD_END_POINT = "pay";
}
