package miu.sa.payment.util;

public class ServicesURL {
    public static String CREDIT_CARD_SERVICE_URL = "http://localhost:8083/";
    public static String PAYPAL_SERVICE_URL = "http://localhost:8085/";
    public static String BANK_ACCOUNT_SERVICE_URL = "http://localhost:8084/";
}
