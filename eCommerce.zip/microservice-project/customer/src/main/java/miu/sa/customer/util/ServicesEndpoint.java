package miu.sa.customer.util;

public class ServicesEndpoint {
    public static String PLACE_ORDER_END_POINT = "placeOrder";
}
