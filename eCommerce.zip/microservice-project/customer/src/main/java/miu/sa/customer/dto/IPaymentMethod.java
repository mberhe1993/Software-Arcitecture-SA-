package miu.sa.customer.dto;

public interface IPaymentMethod {
}
