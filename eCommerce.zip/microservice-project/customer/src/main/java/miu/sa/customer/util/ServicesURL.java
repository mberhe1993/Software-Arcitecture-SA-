package miu.sa.customer.util;

public class ServicesURL {
    public static String ORDER_SERVICE_URL = "http://localhost:8087/";
}
