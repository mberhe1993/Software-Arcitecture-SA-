package shipping.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import shipping.model.Item;

import java.util.List;

@Getter @Setter @NoArgsConstructor
public class ShippingRequest {
    private int orderId;
    private List<ItemRequest> items;
}
