package miu.sa.paypalTransaction;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaypalTransactionApplication {
    public static void main(String[] args) {
        SpringApplication.run(PaypalTransactionApplication.class, args);
    }
}
