package miu.sa.order.util;

public class ServicesURL {
    public static String PRODUCT_SERVICE_URL = "http://localhost:8081/";
    public static String PAYMENT_SERVICE_URL = "http://localhost:8082/";
    public static String SHIPPING_SERVICE_URL = "http://localhost:8088/";
}
