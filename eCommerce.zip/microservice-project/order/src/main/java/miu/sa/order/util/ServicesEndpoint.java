package miu.sa.order.util;

public class ServicesEndpoint {
    public static String CHECK_PRODUCT_END_POINT = "checkproduct";
    public static String MAKE_PAYMENT_END_POINT = "makepayment";
    public static String SHIP_ORDER_END_POINT = "shipOrder";
}
