package miu.sa.product.service.Impl;

import miu.sa.product.model.Seller;
import miu.sa.product.repository.SellerRepository;
import miu.sa.product.service.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SellerServiceImpl implements SellerService {
    @Autowired
    private SellerRepository sellerRepository;

    @Override
    public List<Seller> getSellers() {
        return sellerRepository.findAll();
    }

    @Override
    public Seller getSellerById(Integer id) {
        return sellerRepository.getById(id);
    }

    @Override
    public Seller saveSeller(Seller seller) {
        return sellerRepository.save(seller);
    }

    @Override
    public Seller updateSeller(Seller seller, Integer id) {
        return sellerRepository.save(seller);
    }
}
