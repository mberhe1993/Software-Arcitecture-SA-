package miu.sa.product.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import miu.sa.product.dto.ApiResponse;
import miu.sa.product.dto.Item;
import miu.sa.product.dto.OrderRequest;
import miu.sa.product.model.Product;
import miu.sa.product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
@RestController
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getProducts() {
        return productService.getProducts();
    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Integer id) {
        return productService.getProductById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Integer id){
        productService.deleteProduct(id);
    }

    @PostMapping("/save")
    public void saveProduct(@RequestBody Product product){
        productService.saveProduct(product);
    }

    @PostMapping("/checkproduct")
    public ResponseEntity<?> checkproduct(@Valid @RequestBody OrderRequest request) throws JsonProcessingException {
        List<Product> products = new ArrayList<>();
        for (Item item: request.getItems()) {
            Product p=productService.getProductById(item.getId());
            products.add(p);
            if(p.getStock() < item.getStock()){
                return ResponseEntity.ok(new ApiResponse(false, "Product with Id " + item.getId() + " has not enought quantity"));
            }
        }
        for (int i = 0 ; i < request.getItems().size() ; i++){
            Product product = products.get(i);
            product.setStock(product.getStock() - request.getItems().get(i).getStock());
            /*if(product.getStock() <= CONFIG_VAL){
                //notify seller
            }*/
        }
        productService.saveProducts(products);
        return ResponseEntity.ok(new ApiResponse(true, ""));
    }








}
