package miu.sa.product.controller;

import miu.sa.product.model.Seller;
import miu.sa.product.repository.SellerRepository;
import miu.sa.product.service.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seller")
public class SellerController {
    @Autowired
    private SellerService sellerService;


    @GetMapping
    public List<Seller> getSellers() {
        return sellerService.getSellers();
    }

    @GetMapping("/{id}")
    public Seller getSellerById(@PathVariable Integer id) {
        return sellerService.getSellerById(id);
    }

    @PostMapping
    public Seller saveSeller(@RequestBody Seller seller) {
        return sellerService.saveSeller(seller);
    }

    @PutMapping("/{id}")
    public Seller updateSeller(@RequestBody Seller seller,@PathVariable Integer id) {
        return sellerService.updateSeller(seller,id);
    }









}
