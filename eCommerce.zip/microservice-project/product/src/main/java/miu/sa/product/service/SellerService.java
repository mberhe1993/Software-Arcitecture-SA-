package miu.sa.product.service;

import miu.sa.product.model.Seller;

import java.util.List;

public interface SellerService {
    public List<Seller> getSellers();
    public Seller getSellerById(Integer id);
    public Seller saveSeller(Seller seller);
    public Seller updateSeller(Seller seller,Integer id);
}
