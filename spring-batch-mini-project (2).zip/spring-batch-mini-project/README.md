           Project About Spring-boot-batch 
* Authors *
1. mhreteab 2. Nahom

# About MySql configration
1. create local sql new port with port number 3307
2. naming as mini-project
3. Username= root
4. password= root
5. Schema name = mini-project

*authentication Credentials*
1. Username=mhrie Password= mhrie (admin)
2. Username=nahom password= namhom (user)

# How to access the app #
1. Extract zip file
2. you can find configration for the database in .yml and application.properties
3. create new instance of Mysql with the same schema name
4. Test for connection
6. In terminal you can you this comands to build an image and run
------->  docker-compose build
------->  docker-compose up
7. In post man to to run these end point
   POST: http://localhost:8070/users/importUsers
 Type Username = mhrie and password= mhrie you shouldnt login with user account 
      Username = nahom and password= nahom
8.you should get 200ok massge telling that the there is no any error
9. Go to MySql bench and check the .csv data
10. You should see 5 cloumns and 20 raws
11. We push our application in DockerHub
11. check in database if the given age is converted from integere to Date Value






