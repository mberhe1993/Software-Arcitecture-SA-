package com.javatechie.spring.batch.config;

import com.javatechie.spring.batch.entity.User;
import org.springframework.batch.item.ItemProcessor;

import java.time.LocalDate;

public class userProcessor implements ItemProcessor<User, User> {

    @Override
    public User process(User user) throws Exception {
        Integer age = user.getAge();
        LocalDate today = LocalDate.now();
        Integer year = today.getYear() - age;
        user.setAge(year);
        return user;

    }



}
