package com.javatechie.spring.batch.repository;

import com.javatechie.spring.batch.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface userRepository extends JpaRepository<User,Integer> {
}
