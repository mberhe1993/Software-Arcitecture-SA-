
************ User-service read me file *******************
* First we have to create a role
we have two roles ADMIN, and RENTER

1. adding role
 name="ROLE_ADMIN"

this is the jason file from post man.

{
    "name":"ROLE_ADMIN"
}
_________________________________________________

2. To register a new user, user should signup and should provide the following

username= "mberhe@miu.edu"
password="123456"
Role= "ADMIN"
usertype= "ADMIN"

this is the jason file from post man.
{
    "username": "",
    "password": "123456",
    "Role": [
        "ADMIN"
    ],
    "userType": "ADMIN"
}

_________________________________________________

3. signning in a user from account service
username= "mberhe@miu.edu"
password="2136547"


this is the jason file from post man.

